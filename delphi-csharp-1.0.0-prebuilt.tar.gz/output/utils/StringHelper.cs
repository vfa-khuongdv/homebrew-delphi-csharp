using System;
using System.Linq;

namespace StringHelper
{
    public static class StringHelper
    {
        // Checks if the given string is empty or consists only of whitespace characters
        public static bool IsEmpty(string value)
        {
            return string.IsNullOrWhiteSpace(value);
        }

        // Capitalizes the first letter of the given string and makes the rest lowercase
        public static string Capitalize(string value)
        {
            if (string.IsNullOrEmpty(value))
            return string.Empty;

            return char.ToUpper(value[0]) + value.Substring(1).ToLower();
        }

        // Removes all spaces from the given string
        public static string RemoveSpaces(string value)
        {
            return string.Concat(value.Where(c => c != ' '));
        }

        // Counts the number of words in the given string
        public static int CountWords(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            return 0;

            return value.Trim().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Length;
        }
    }
}
