using System;

namespace PersonNamespace
{
    public class Person
    {
        private string _name;
        private int _age;

        public Person(string name, int age)
        {
            _name = name;
            Age = age; // Use the property to set age
        }

        public string Name
        {
            get => _name;
            set => _name = value;
        }

        public int Age
        {
            get => _age;
            set => SetAge(value);
        }

        public string GetFullInfo()
        {
            return $"{_name} is {_age} years old";
        }

        private void SetAge(int value)
        {
            if (value >= 0)
            _age = value;
            else
            throw new ArgumentException("Age cannot be negative");
        }
    }
}
