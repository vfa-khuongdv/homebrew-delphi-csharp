using System;
using System.Collections.Generic;
using System.Text;

namespace CompanyManager
{
    public class CompanyManager
    {
        private readonly List<Employee> _employees;
        private string _companyName;

        public CompanyManager(string companyName)
        {
            _companyName = StringHelper.Capitalize(companyName);
            _employees = new List<Employee>(); // Does not own objects
        }

        public void AddEmployee(Employee employee)
        {
            if (employee == null)
            throw new ArgumentNullException(nameof(employee), "Employee cannot be null");

            if (FindEmployeeById(employee.EmployeeId) != null)
            throw new InvalidOperationException("Employee with this ID already exists");

            _employees.Add(employee);
        }

        public int GetEmployeeCount()
        {
            return _employees.Count;
        }

        public Employee FindEmployeeById(string id)
        {
            foreach (var employee in _employees)
            {
                if (employee.EmployeeId == id)
                {
                    return employee;
                }
            }
            return null;
        }

        public string GetCompanyReport()
        {
            var report = new StringBuilder();
            report.AppendLine($"Company: {_companyName}");
            report.AppendLine($"Total Employees: {GetEmployeeCount()}");
            report.AppendLine();
            report.AppendLine("Employee List:");

            for (int i = 0; i < _employees.Count; i++)
            {
                var employee = _employees[i];
                report.AppendLine($"{i + 1}. {employee.GetEmployeeInfo()}");
            }

            return report.ToString();
        }

        public void RemoveEmployee(string id)
        {
            var employee = FindEmployeeById(id);
            if (employee != null)
            {
                _employees.Remove(employee);
            }
            else
            {
                throw new KeyNotFoundException("Employee not found");
            }
        }

        public string CompanyName
        {
            get => _companyName;
            set => _companyName = value;
        }

        public List<Employee> Employees => _employees;
    }
}
