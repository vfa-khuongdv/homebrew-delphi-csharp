using System;

namespace Calculator
{
    public class Calculator
    {
        private double _result;

        public Calculator()
        {
            _result = 0.0;
        }

        public double Add(double a, double b)
        {
            _result = a + b;
            return _result;
        }

        public double Subtract(double a, double b)
        {
            _result = a - b;
            return _result;
        }

        public double Multiply(double a, double b)
        {
            _result = a * b;
            return _result;
        }

        public double Divide(double a, double b)
        {
            if (b != 0)
            {
                _result = a / b;
                return _result;
            }
            else
            {
                throw new DivideByZeroException("Division by zero");
            }
        }

        public double Result
        {
            get => _result;
            set => _result = value;
        }
    }
}
