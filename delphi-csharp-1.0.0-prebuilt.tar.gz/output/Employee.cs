using System;
using Utils; // Assuming the equivalent namespace for StringHelper
using Models; // Assuming the equivalent namespace for Person

namespace Employee
{
    public class Employee : Person
    {
        private string employeeId;
        private double salary;
        private string department;

        public Employee(string name, int age, string employeeId, double salary, string department)
        : base(name, age)
        {
            this.employeeId = employeeId;
            this.salary = salary;
            this.department = StringHelper.Capitalize(department);
            ValidateEmployeeData();
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        public string GetEmployeeInfo()
        {
            return string.Format("Employee {0} ({1}) - {2}, Age: {3}, Salary: {4}",
            employeeId, Name, department, Age, GetFormattedSalary());
        }

        public string GetFormattedSalary()
        {
            return string.Format("${0:F2}", salary);
        }

        public void ValidateEmployeeData()
        {
            if (StringHelper.IsEmpty(employeeId))
            throw new Exception("Employee ID cannot be empty");

            if (StringHelper.IsEmpty(department))
            throw new Exception("Department cannot be empty");

            if (salary < 0)
            throw new Exception("Salary cannot be negative");

            // Validate name using StringHelper
            if (StringHelper.IsEmpty(Name))
            throw new Exception("Employee name cannot be empty");
        }

        public string EmployeeId
        {
            get => employeeId;
            set => employeeId = value;
        }

        public double Salary
        {
            get => salary;
            set => salary = value;
        }

        public string Department
        {
            get => department;
            set => department = value;
        }
    }
}
